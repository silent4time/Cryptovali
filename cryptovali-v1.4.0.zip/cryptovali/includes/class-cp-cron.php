<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CP_Cron {

	public static function init() {
		add_action( 'cp_custom_check_payments', [ __CLASS__, 'check_pending_orders' ] );
	}

	/**
	 * پیدا کردن سفارش‌های در انتظار پرداخت ارز دیجیتال و بررسی تراکنش‌های ورودی
	 */
	public static function check_pending_orders() {
		$gateway_settings = get_option( 'woocommerce_cryptovali_settings', [] );

		$pending_orders = wc_get_orders( [
			'status'     => 'on-hold',
			'limit'      => -1,
			'meta_key'   => '_cp_status',
			'meta_value' => 'awaiting_payment',
		] );

		if ( empty( $pending_orders ) ) {
			return;
		}

		// دسته‌بندی سفارش‌ها بر اساس شبکه، برای اینکه هر شبکه فقط یک‌بار از API پرسیده شود
		$by_network = [
			'BNB_BEP20'  => [],
			'USDT_BEP20' => [],
			'USDT_TRC20' => [],
		];

		foreach ( $pending_orders as $order ) {
			$expires_at = (int) $order->get_meta( '_cp_expires_at' );
			if ( time() > $expires_at ) {
				$order->update_meta_data( '_cp_status', 'expired' );
				$order->update_status( 'cancelled', __( 'مهلت پرداخت ارز دیجیتال به پایان رسید.', 'cryptovali' ) );
				$order->save();
				continue;
			}

			$network = $order->get_meta( '_cp_network' );
			if ( isset( $by_network[ $network ] ) ) {
				$by_network[ $network ][] = $order;
			}
		}

		if ( ! empty( $by_network['BNB_BEP20'] ) ) {
			self::process_network(
				$by_network['BNB_BEP20'],
				$gateway_settings['bnb_bep20_address'] ?? '',
				CP_Chain_API::get_bnb_transfers( $gateway_settings['bnb_bep20_address'] ?? '', $gateway_settings['bscscan_api_key'] ?? '' ),
				'bnb'
			);
		}

		if ( ! empty( $by_network['USDT_BEP20'] ) ) {
			self::process_network(
				$by_network['USDT_BEP20'],
				$gateway_settings['usdt_bep20_address'] ?? '',
				CP_Chain_API::get_bep20_token_transfers( $gateway_settings['usdt_bep20_address'] ?? '', CP_Chain_API::USDT_BEP20_CONTRACT, $gateway_settings['bscscan_api_key'] ?? '' ),
				'bep20_token'
			);
		}

		if ( ! empty( $by_network['USDT_TRC20'] ) ) {
			self::process_network(
				$by_network['USDT_TRC20'],
				$gateway_settings['usdt_trc20_address'] ?? '',
				CP_Chain_API::get_trc20_token_transfers( $gateway_settings['usdt_trc20_address'] ?? '', $gateway_settings['trongrid_api_key'] ?? '' ),
				'trc20'
			);
		}
	}

	/**
	 * تطبیق تراکنش‌های دریافتی از API با سفارش‌های در انتظار همان شبکه
	 */
	private static function process_network( $orders, $address, $api_response, $source_type ) {
		if ( empty( $address ) || is_wp_error( $api_response ) || empty( $api_response ) ) {
			return;
		}

		$transfers = self::normalize_transfers( $api_response, $address, $source_type );
		if ( empty( $transfers ) ) {
			return;
		}

		foreach ( $orders as $order ) {
			// اگر همین حالا در حال پردازش توسط اجرای موازی کرون است، رد شو (جلوگیری از race condition ساده)
			if ( $order->get_meta( '_cp_status' ) !== 'awaiting_payment' ) {
				continue;
			}

			$expected      = (float) $order->get_meta( '_cp_expected_amount' );
			$created_at    = (int) $order->get_meta( '_cp_created_at' );
			$tolerance_pct = (float) get_option( 'cp_amount_tolerance', 0.5 );
			$gw_settings   = get_option( 'woocommerce_cryptovali_settings', [] );
			$tolerance_pct = isset( $gw_settings['amount_tolerance'] ) ? (float) $gw_settings['amount_tolerance'] : 0.5;
			$tolerance     = $expected * ( $tolerance_pct / 100 );

			foreach ( $transfers as $tx ) {
				// تراکنش باید بعد از زمان ایجاد سفارش انجام شده باشد
				if ( $tx['timestamp'] < $created_at - 120 ) { // ۲ دقیقه اغماض برای اختلاف ساعت سرور
					continue;
				}

				if ( abs( $tx['amount'] - $expected ) <= max( $tolerance, 0.00000010 ) ) {
					self::mark_order_paid( $order, $tx );
					break;
				}
			}
		}
	}

	/**
	 * یکسان‌سازی خروجی APIهای مختلف به یک ساختار مشترک: [amount, timestamp, hash]
	 */
	private static function normalize_transfers( $api_response, $address, $source_type ) {
		$list = [];

		if ( $source_type === 'bnb' && isset( $api_response['result'] ) && is_array( $api_response['result'] ) ) {
			foreach ( $api_response['result'] as $tx ) {
				if ( strtolower( $tx['to'] ?? '' ) !== strtolower( $address ) ) {
					continue;
				}
				$list[] = [
					'amount'    => ( (float) $tx['value'] ) / 1e18,
					'timestamp' => (int) $tx['timeStamp'],
					'hash'      => $tx['hash'],
				];
			}
		} elseif ( $source_type === 'bep20_token' && isset( $api_response['result'] ) && is_array( $api_response['result'] ) ) {
			foreach ( $api_response['result'] as $tx ) {
				if ( strtolower( $tx['to'] ?? '' ) !== strtolower( $address ) ) {
					continue;
				}
				$decimals = isset( $tx['tokenDecimal'] ) ? (int) $tx['tokenDecimal'] : 18;
				$list[]   = [
					'amount'    => ( (float) $tx['value'] ) / pow( 10, $decimals ),
					'timestamp' => (int) $tx['timeStamp'],
					'hash'      => $tx['hash'],
				];
			}
		} elseif ( $source_type === 'trc20' && isset( $api_response['data'] ) && is_array( $api_response['data'] ) ) {
			foreach ( $api_response['data'] as $tx ) {
				$to = $tx['to'] ?? '';
				if ( $to !== $address ) {
					continue;
				}
				$decimals = isset( $tx['token_info']['decimals'] ) ? (int) $tx['token_info']['decimals'] : 6;
				$list[]   = [
					'amount'    => ( (float) $tx['value'] ) / pow( 10, $decimals ),
					'timestamp' => (int) round( ( $tx['block_timestamp'] ?? 0 ) / 1000 ),
					'hash'      => $tx['transaction_id'] ?? '',
				];
			}
		}

		return $list;
	}

	/**
	 * ثبت پرداخت موفق روی سفارش
	 */
	private static function mark_order_paid( $order, $tx ) {
		$order->update_meta_data( '_cp_status', 'paid' );
		$order->update_meta_data( '_cp_tx_hash', $tx['hash'] );
		$order->add_order_note(
			sprintf(
				/* translators: %1$s: tx hash, %2$s: amount */
				__( 'پرداخت ارز دیجیتال تأیید شد. هش تراکنش: %1$s — مبلغ دریافتی: %2$s', 'cryptovali' ),
				$tx['hash'],
				$tx['amount']
			)
		);
		$order->payment_complete( $tx['hash'] );
		$order->save();
	}
}
