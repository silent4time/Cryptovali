<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * اتصال افزونه به سیستم بروزرسانی داخلی وردپرس با استفاده از GitHub Releases.
 * وقتی یک Release جدید (با شماره نسخه بالاتر) روی گیت‌هاب منتشر شود، وردپرس
 * دقیقاً مثل افزونه‌های موجود در ریپازیتوری رسمی، اعلان «بروزرسانی موجود است»
 * نشان می‌دهد و کاربر می‌تواند با یک کلیک آپدیت کند.
 */
class CP_GitHub_Updater {

	// نام کاربری/سازمان و نام ریپازیتوری روی گیت‌هاب
	const GITHUB_OWNER = 'silent4time';
	const GITHUB_REPO  = 'Cryptovali';

	// مسیر نسبی فایل اصلی افزونه (پوشه/فایل.php) — باید با نام واقعی پوشه نصب‌شده یکی باشد
	const PLUGIN_BASENAME = 'cryptovali/cryptovali.php';

	const CACHE_KEY = 'cp_github_release_cache';

	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', [ __CLASS__, 'check_update' ] );
		add_filter( 'plugins_api', [ __CLASS__, 'plugin_info_popup' ], 20, 3 );
		add_filter( 'upgrader_source_selection', [ __CLASS__, 'fix_folder_name' ], 10, 4 );
		add_filter( 'plugin_row_meta', [ __CLASS__, 'add_check_update_link' ], 10, 2 );
		add_action( 'admin_init', [ __CLASS__, 'maybe_force_check' ] );
	}

	/**
	 * دریافت اطلاعات آخرین Release از GitHub API (با کش ۶ ساعته برای جلوگیری از محدودیت نرخ درخواست)
	 */
	private static function get_latest_release() {
		$cached = get_transient( self::CACHE_KEY );
		if ( false !== $cached ) {
			return $cached;
		}

		$url = sprintf(
			'https://api.github.com/repos/%s/%s/releases/latest',
			self::GITHUB_OWNER,
			self::GITHUB_REPO
		);

		$response = wp_remote_get( $url, [
			'timeout' => 15,
			'headers' => [
				'Accept'     => 'application/vnd.github+json',
				'User-Agent' => 'Cryptovali-Updater-WordPress',
			],
		] );

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			// در صورت خطا، یک کش کوتاه (۵ دقیقه) از "هیچی" بگذار تا بمباران درخواست نشه
			set_transient( self::CACHE_KEY, [], 5 * MINUTE_IN_SECONDS );
			return [];
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['tag_name'] ) ) {
			set_transient( self::CACHE_KEY, [], 5 * MINUTE_IN_SECONDS );
			return [];
		}

		$version = ltrim( $body['tag_name'], 'vV' );

		// اول دنبال فایلی با اسم شبیه cryptovali-*.zip بین ضمیمه‌های Release بگرد (ساختار پوشه‌اش تضمین‌شده درست است)
		$package_url = '';
		if ( ! empty( $body['assets'] ) && is_array( $body['assets'] ) ) {
			foreach ( $body['assets'] as $asset ) {
				if ( preg_match( '/^cryptovali.*\.zip$/i', $asset['name'] ?? '' ) ) {
					$package_url = $asset['browser_download_url'];
					break;
				}
			}
		}
		// در صورت نبود ضمیمه‌ی دستی، از zip خودکار سورس‌کد گیت‌هاب استفاده کن
		if ( empty( $package_url ) && ! empty( $body['zipball_url'] ) ) {
			$package_url = $body['zipball_url'];
		}

		$data = [
			'version'      => $version,
			'package_url'  => $package_url,
			'release_url'  => $body['html_url'] ?? '',
			'changelog'    => $body['body'] ?? '',
			'published_at' => $body['published_at'] ?? '',
		];

		set_transient( self::CACHE_KEY, $data, 6 * HOUR_IN_SECONDS );

		return $data;
	}

	/**
	 * تزریق اطلاعات بروزرسانی به سیستم داخلی وردپرس، اگر نسخه‌ی جدیدتری روی گیت‌هاب باشد
	 */
	public static function check_update( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		$release = self::get_latest_release();
		if ( empty( $release['version'] ) || empty( $release['package_url'] ) ) {
			return $transient;
		}

		if ( version_compare( $release['version'], CRYPTOVALI_VERSION, '>' ) ) {
			$item = (object) [
				'id'            => self::GITHUB_OWNER . '/' . self::GITHUB_REPO,
				'slug'          => 'cryptovali',
				'plugin'        => self::PLUGIN_BASENAME,
				'new_version'   => $release['version'],
				'url'           => $release['release_url'],
				'package'       => $release['package_url'],
				'icons'         => [],
				'banners'       => [],
				'tested'        => '',
				'requires_php'  => '',
			];
			$transient->response[ self::PLUGIN_BASENAME ] = $item;
			unset( $transient->no_update[ self::PLUGIN_BASENAME ] );
		} else {
			// صراحتاً اعلام کن که به‌روزه، تا وردپرس دوباره چک نکنه و پیام اشتباه نده
			$item = (object) [
				'id'          => self::GITHUB_OWNER . '/' . self::GITHUB_REPO,
				'slug'        => 'cryptovali',
				'plugin'      => self::PLUGIN_BASENAME,
				'new_version' => CRYPTOVALI_VERSION,
			];
			$transient->no_update[ self::PLUGIN_BASENAME ] = $item;
		}

		return $transient;
	}

	/**
	 * پاپ‌آپ «مشاهده جزئیات نسخه» در صفحه افزونه‌ها
	 */
	public static function plugin_info_popup( $result, $action, $args ) {
		if ( $action !== 'plugin_information' || empty( $args->slug ) || $args->slug !== 'cryptovali' ) {
			return $result;
		}

		$release = self::get_latest_release();
		if ( empty( $release['version'] ) ) {
			return $result;
		}

		return (object) [
			'name'          => 'Cryptovali',
			'slug'          => 'cryptovali',
			'version'       => $release['version'],
			'author'        => '<a href="https://github.com/' . self::GITHUB_OWNER . '">Cryptovali</a>',
			'homepage'      => 'https://github.com/' . self::GITHUB_OWNER . '/' . self::GITHUB_REPO,
			'download_link' => $release['package_url'],
			'sections'      => [
				'description' => 'درگاه پرداخت مستقیم ارز دیجیتال برای ووکامرس (BNB/USDT روی BEP20 و TRC20).',
				'changelog'   => nl2br( esc_html( $release['changelog'] ?: 'بدون یادداشت تغییرات.' ) ),
			],
		];
	}

	/**
	 * اصلاح نام پوشه‌ی استخراج‌شده هنگام آپدیت، تا با نام واقعی پوشه‌ی نصب‌شده (cryptovali) یکی باشد.
	 * لازم است چون zip خودکار گیت‌هاب معمولاً پوشه‌ای با نام کاربر/ریپو-هش می‌سازد.
	 */
	public static function fix_folder_name( $source, $remote_source, $upgrader, $extra_args ) {
		global $wp_filesystem;

		if ( empty( $extra_args['plugin'] ) || $extra_args['plugin'] !== self::PLUGIN_BASENAME ) {
			return $source;
		}

		$desired_slug = 'cryptovali';
		$current_name = basename( untrailingslashit( $source ) );

		if ( $current_name === $desired_slug ) {
			return $source;
		}

		$new_source = trailingslashit( $remote_source ) . $desired_slug . '/';

		if ( $wp_filesystem->move( $source, $new_source, true ) ) {
			return $new_source;
		}

		return $source;
	}

	/**
	 * افزودن لینک «بررسی بروزرسانی جدید» زیر نام افزونه در لیست افزونه‌ها
	 */
	public static function add_check_update_link( $links, $file ) {
		if ( $file !== self::PLUGIN_BASENAME ) {
			return $links;
		}

		$url = wp_nonce_url(
			add_query_arg( 'cp_force_update_check', '1', admin_url( 'plugins.php' ) ),
			'cp_force_update_check'
		);

		$links[] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'بررسی بروزرسانی جدید', 'cryptovali' ) . '</a>';

		return $links;
	}

	/**
	 * وقتی کاربر روی «بررسی بروزرسانی جدید» کلیک کند: کش را پاک و مجدداً چک کن
	 */
	public static function maybe_force_check() {
		if ( ! isset( $_GET['cp_force_update_check'] ) || ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		if ( ! check_admin_referer( 'cp_force_update_check' ) ) {
			return;
		}

		delete_transient( self::CACHE_KEY );
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();

		wp_safe_redirect( admin_url( 'plugins.php?cp_update_checked=1' ) );
		exit;
	}
}
