<?php
/**
 * Plugin Name: Cryptovali - Crypto Payment Gateway for WooCommerce
 * Plugin URI:  https://github.com/YOUR-USERNAME/cryptovali
 * Description: دریافت پرداخت مستقیم و خودکار ارز دیجیتال در ووکامرس (BNB - BEP20، USDT - BEP20، USDT - TRC20) بدون کارمزد و بدون واسطه بانکی.
 * Version:     1.5.0
 * Author:      Cryptovali
 * Text Domain: cryptovali
 * Domain Path: /languages
 * Requires Plugins: woocommerce
 * WC requires at least: 8.0
 * WC tested up to: 9.5
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CRYPTOVALI_VERSION', '1.5.0' );
define( 'CRYPTOVALI_PATH', plugin_dir_path( __FILE__ ) );
define( 'CRYPTOVALI_URL', plugin_dir_url( __FILE__ ) );

/**
 * چک می‌کنیم ووکامرس فعال باشه
 */
function cp_custom_check_woocommerce() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>' .
				esc_html__( 'افزونه Cryptovali نیاز به فعال بودن ووکامرس دارد.', 'cryptovali' ) .
				'</p></div>';
		} );
		return false;
	}
	return true;
}

/**
 * اعلام سازگاری با HPOS (High-Performance Order Storage) ووکامرس
 */
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
			'custom_order_tables',
			__FILE__,
			true
		);
	}
} );

/**
 * بارگذاری فایل‌های افزونه
 */
function cp_custom_includes() {
	require_once CRYPTOVALI_PATH . 'includes/class-cp-fields.php';
	require_once CRYPTOVALI_PATH . 'includes/class-cp-rate.php';
	require_once CRYPTOVALI_PATH . 'includes/class-cp-chain-api.php';
	require_once CRYPTOVALI_PATH . 'includes/class-cp-gateway.php';
	require_once CRYPTOVALI_PATH . 'includes/class-cp-cron.php';
	require_once CRYPTOVALI_PATH . 'includes/class-cp-ajax.php';
	require_once CRYPTOVALI_PATH . 'includes/class-cp-admin-dashboard.php';
	require_once CRYPTOVALI_PATH . 'includes/class-cp-github-updater.php';
}

add_action( 'plugins_loaded', function () {
	if ( ! cp_custom_check_woocommerce() ) {
		return;
	}
	cp_custom_includes();
	CP_Cron::init();
	CP_Ajax::init();
	CP_Admin_Dashboard::init();

	if ( is_admin() ) {
		CP_GitHub_Updater::init();
	}
}, 20 );

/**
 * ثبت گیت‌وی پرداخت در ووکامرس
 */
add_filter( 'woocommerce_payment_gateways', function ( $gateways ) {
	$gateways[] = 'CP_Gateway';
	return $gateways;
} );

/**
 * فعال‌سازی: زمان‌بندی کرون
 */
register_activation_hook( __FILE__, function () {
	if ( ! wp_next_scheduled( 'cp_custom_check_payments' ) ) {
		wp_schedule_event( time(), 'cp_every_minute', 'cp_custom_check_payments' );
	}
} );

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'cp_custom_check_payments' );
} );

/**
 * افزودن بازه‌ی زمانی «هر یک دقیقه» به کرون وردپرس
 */
add_filter( 'cron_schedules', function ( $schedules ) {
	$schedules['cp_every_minute'] = [
		'interval' => 60,
		'display'  => __( 'هر ۱ دقیقه (Cryptovali)', 'cryptovali' ),
	];
	return $schedules;
} );

/**
 * بارگذاری اسکریپت و استایل در صفحه پرداخت سفارش
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( is_wc_endpoint_url( 'order-pay' ) || is_checkout() ) {
		wp_enqueue_style( 'cryptovali-style', CRYPTOVALI_URL . 'assets/css/cp-style.css', [], CRYPTOVALI_VERSION );
		wp_enqueue_script( 'cp-qrcode-lib', 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js', [], '1.0.0', true );
		wp_enqueue_script( 'cryptovali-checkout', CRYPTOVALI_URL . 'assets/js/cp-checkout.js', [ 'jquery', 'cp-qrcode-lib' ], CRYPTOVALI_VERSION, true );
		wp_localize_script( 'cryptovali-checkout', 'Cryptovali', [
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cp_custom_nonce' ),
		] );
	}
} );
