<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CP_Ajax {

	public static function init() {
		add_action( 'wp_ajax_cp_check_order_status', [ __CLASS__, 'check_order_status' ] );
		add_action( 'wp_ajax_nopriv_cp_check_order_status', [ __CLASS__, 'check_order_status' ] );
	}

	public static function check_order_status() {
		check_ajax_referer( 'cp_custom_nonce', 'nonce' );

		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$order    = wc_get_order( $order_id );

		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'سفارش یافت نشد' ] );
		}

		$status = $order->get_meta( '_cp_status' );

		if ( $status === 'paid' ) {
			wp_send_json_success( [
				'status'   => 'paid',
				'redirect' => $order->get_checkout_order_received_url(),
			] );
		}

		if ( $status === 'expired' || time() > (int) $order->get_meta( '_cp_expires_at' ) ) {
			wp_send_json_success( [ 'status' => 'expired' ] );
		}

		wp_send_json_success( [ 'status' => 'awaiting_payment' ] );
	}
}
