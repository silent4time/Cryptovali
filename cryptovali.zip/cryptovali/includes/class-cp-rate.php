<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * دریافت نرخ لحظه‌ای ارز دیجیتال نسبت به واحد پول فروشگاه (از CoinGecko - رایگان و بدون نیاز به کلید)
 */
class CP_Rate {

	// شناسه‌ی ارزها در CoinGecko
	const COINGECKO_IDS = [
		'BNB'  => 'binancecoin',
		'USDT' => 'tether',
		'TRX'  => 'tron',
	];

	/**
	 * گرفتن نرخ ۱ واحد از ارز مشخص‌شده به واحد پول فروشگاه (fiat)
	 * نتیجه به مدت ۹۰ ثانیه کش می‌شود تا فشار زیادی روی API نباشد.
	 *
	 * @param string $symbol BNB یا USDT
	 * @return float|WP_Error
	 */
	public static function get_rate( $symbol ) {
		$symbol = strtoupper( $symbol );
		$fiat   = strtolower( get_woocommerce_currency() );

		if ( ! isset( self::COINGECKO_IDS[ $symbol ] ) ) {
			return new WP_Error( 'cp_rate_unknown_symbol', 'ارز پشتیبانی نمی‌شود: ' . $symbol );
		}

		$cache_key = 'cp_rate_' . $symbol . '_' . $fiat;
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return (float) $cached;
		}

		$coin_id = self::COINGECKO_IDS[ $symbol ];
		$url     = add_query_arg(
			[
				'ids'           => $coin_id,
				'vs_currencies' => $fiat,
			],
			'https://api.coingecko.com/api/v3/simple/price'
		);

		$response = wp_remote_get( $url, [ 'timeout' => 15 ] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body[ $coin_id ][ $fiat ] ) ) {
			// اگر واحد پول فروشگاه توسط CoinGecko پشتیبانی نشود (مثلاً IRR)، به USD بازمی‌گردیم
			// و کاربر باید نرخ تبدیل ارز محلی به دلار را جداگانه مدیریت کند.
			return new WP_Error( 'cp_rate_not_found', 'نرخ برای این واحد پول یافت نشد: ' . $fiat );
		}

		$rate = (float) $body[ $coin_id ][ $fiat ];
		set_transient( $cache_key, $rate, 90 );

		return $rate;
	}

	/**
	 * تبدیل مبلغ فیات سفارش به مقدار ارز دیجیتال، به همراه یک «نانس» کوچک اعشاری
	 * برای اینکه بشه سفارش‌های مختلف را حتی روی یک آدرس ثابت از هم تشخیص داد.
	 *
	 * @param float  $fiat_amount
	 * @param string $symbol
	 * @param int    $order_id برای تولید نانس یکتا استفاده می‌شود
	 * @return array|WP_Error ['amount' => float, 'rate' => float]
	 */
	public static function convert_with_nonce( $fiat_amount, $symbol, $order_id ) {
		$rate = self::get_rate( $symbol );
		if ( is_wp_error( $rate ) || $rate <= 0 ) {
			return is_wp_error( $rate ) ? $rate : new WP_Error( 'cp_rate_invalid', 'نرخ نامعتبر است' );
		}

		$base_amount = $fiat_amount / $rate;

		// نانس بین 0.00001 تا 0.00099 بر اساس شناسه سفارش + زمان، برای یکتا بودن مبلغ
		$nonce = ( ( $order_id * 37 + time() ) % 990 + 10 ) / 100000000;

		$final_amount = round( $base_amount + $nonce, 8 );

		return [
			'amount' => $final_amount,
			'rate'   => $rate,
			'nonce'  => $nonce,
		];
	}
}
