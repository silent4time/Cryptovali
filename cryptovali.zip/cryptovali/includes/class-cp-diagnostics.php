<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تست مستقیم و زنده‌ی اتصال خروجی سرور به تمام سرویس‌های خارجی‌ای که افزونه برای
 * کارکرد صحیح خودش (نرخ ارز، تشخیص خودکار واریزی، بروزرسانی) به آن‌ها نیاز دارد.
 * هدف: مشخص کردن اینکه آیا مشکل مختص یک سرویس خاص است یا کل سرور اجازه‌ی
 * اتصال خروجی به دامنه‌های خارجی را ندارد.
 */
class CP_Diagnostics {

	private static function test_endpoint( $label, $url ) {
		$start    = microtime( true );
		$response = wp_remote_get( $url, [ 'timeout' => 10 ] );
		$elapsed  = round( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $response ) ) {
			return [
				'label'      => $label,
				'url'        => $url,
				'success'    => false,
				'error'      => $response->get_error_message(),
				'elapsed_ms' => $elapsed,
			];
		}

		return [
			'label'      => $label,
			'url'        => $url,
			'success'    => true,
			'http_code'  => wp_remote_retrieve_response_code( $response ),
			'elapsed_ms' => $elapsed,
		];
	}

	/**
	 * اجرای تست روی همه‌ی سرویس‌های حیاتی افزونه
	 */
	public static function run_all() {
		return [
			self::test_endpoint( 'CoinGecko (نرخ لحظه‌ای ارز — بخش حیاتی)', 'https://api.coingecko.com/api/v3/ping' ),
			self::test_endpoint( 'BscScan (تشخیص واریز BNB/USDT روی BEP20 — بخش حیاتی)', 'https://api.bscscan.com/api?module=stats&action=ethsupply' ),
			self::test_endpoint( 'TronGrid (تشخیص واریز USDT/TRX روی TRC20 — بخش حیاتی)', 'https://api.trongrid.io/wallet/getnowblock' ),
			self::test_endpoint( 'GitHub API (فقط بروزرسانی افزونه)', 'https://api.github.com' ),
			self::test_endpoint( 'jsDelivr (فقط بروزرسانی جایگزین)', 'https://data.jsdelivr.com/v1/packages/npm/react' ),
		];
	}
}
