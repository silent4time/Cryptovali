<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ارتباط با اکسپلوررهای رایگان بلاک‌چین برای پیدا کردن تراکنش‌های واریزی
 */
class CP_Chain_API {

	// آدرس قرارداد توکن USDT روی هر شبکه
	const USDT_BEP20_CONTRACT = '0x55d398326f99059fF775485246999027B3197955';
	const USDT_TRC20_CONTRACT = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

	/**
	 * دریافت لیست تراکنش‌های واریزی BNB (توکن بومی BEP20) به یک آدرس
	 * از BscScan API (رایگان، فقط نیاز به ثبت‌نام و گرفتن API Key رایگان در bscscan.com)
	 */
	public static function get_bnb_transfers( $address, $api_key ) {
		$url = add_query_arg(
			[
				'module'  => 'account',
				'action'  => 'txlist',
				'address' => $address,
				'sort'    => 'desc',
				'apikey'  => $api_key,
			],
			'https://api.bscscan.com/api'
		);

		return self::fetch_json( $url );
	}

	/**
	 * دریافت لیست تراکنش‌های واریزی توکن (USDT-BEP20) به یک آدرس از BscScan
	 */
	public static function get_bep20_token_transfers( $address, $contract, $api_key ) {
		$url = add_query_arg(
			[
				'module'          => 'account',
				'action'          => 'tokentx',
				'contractaddress' => $contract,
				'address'         => $address,
				'sort'            => 'desc',
				'apikey'          => $api_key,
			],
			'https://api.bscscan.com/api'
		);

		return self::fetch_json( $url );
	}

	/**
	 * دریافت لیست تراکنش‌های واریزی توکن TRC20 (USDT) به یک آدرس ترون
	 * از TronGrid API (رایگان و بدون نیاز اجباری به کلید برای حجم پایین)
	 */
	public static function get_trc20_token_transfers( $address, $api_key = '' ) {
		$url = "https://api.trongrid.io/v1/accounts/{$address}/transactions/trc20";
		$url = add_query_arg(
			[
				'limit'           => 50,
				'contract_address'=> self::USDT_TRC20_CONTRACT,
				'only_to'         => 'true',
				'order_by'        => 'block_timestamp,desc',
			],
			$url
		);

		$headers = [];
		if ( ! empty( $api_key ) ) {
			$headers['TRON-PRO-API-KEY'] = $api_key;
		}

		return self::fetch_json( $url, $headers );
	}

	/**
	 * دریافت لیست تراکنش‌های بومی TRX (نه توکن، بلکه خودِ ارز اصلی ترون) واریزشده به یک آدرس
	 * از TronGrid API
	 */
	public static function get_trx_transfers( $address, $api_key = '' ) {
		$url = "https://api.trongrid.io/v1/accounts/{$address}/transactions";
		$url = add_query_arg(
			[
				'limit'    => 50,
				'only_to'  => 'true',
				'only_confirmed' => 'true',
				'order_by' => 'block_timestamp,desc',
			],
			$url
		);

		$headers = [];
		if ( ! empty( $api_key ) ) {
			$headers['TRON-PRO-API-KEY'] = $api_key;
		}

		return self::fetch_json( $url, $headers );
	}

	/**
	 * فراخوانی HTTP و بازگرداندن JSON
	 */
	private static function fetch_json( $url, $headers = [] ) {
		$args = [ 'timeout' => 20 ];
		if ( ! empty( $headers ) ) {
			$args['headers'] = $headers;
		}

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code !== 200 ) {
			return new WP_Error( 'cp_chain_http_error', 'خطای HTTP ' . $code . ' از ' . $url );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		return $body;
	}
}
