jQuery(function ($) {
	var $popup = $('#cp-help-popup');
	var $popupText = $('#cp-help-popup-text');

	if (!$popup.length) {
		return;
	}

	$(document).on('click', '.cp-help-icon', function (e) {
		e.preventDefault();
		var text = $(this).data('help');
		$popupText.text(text);
		$popup.prop('hidden', false);
	});

	function closePopup() {
		$popup.prop('hidden', true);
	}

	$('#cp-help-popup-close').on('click', closePopup);

	// کلیک روی پس‌زمینه تیره هم پاپ‌آپ را ببندد
	$popup.on('click', function (e) {
		if (e.target === this) {
			closePopup();
		}
	});

	// کلید Esc هم پاپ‌آپ را ببندد
	$(document).on('keyup', function (e) {
		if (e.key === 'Escape') {
			closePopup();
		}
	});
});
