jQuery(function ($) {
	var $wrap = $('.cp-receipt-wrap');
	if (!$wrap.length) {
		return;
	}

	var orderId = $wrap.data('order-id');
	var expiresAt = parseInt($wrap.data('expires'), 10) * 1000; // ms
	var $countdown = $('#cp-countdown');
	var $statusBox = $('.cp-status-box');
	var $statusText = $('#cp-status-text');
	var pollTimer = null;

	// --- QR Code ---
	var address = $('#cp-address').text().trim();
	if (window.QRCode && address) {
		new QRCode(document.getElementById('cp-qrcode'), {
			text: address,
			width: 180,
			height: 180
		});
	}

	// --- کپی کردن ---
	$('.cp-copy-btn').on('click', function () {
		var text = $(this).data('copy');
		navigator.clipboard.writeText(String(text)).then(() => {
			var original = $(this).text();
			$(this).text('کپی شد ✓');
			var $btn = $(this);
			setTimeout(function () {
				$btn.text(original);
			}, 1500);
		});
	});

	// --- شمارش معکوس ---
	function tickCountdown() {
		var remaining = expiresAt - Date.now();
		if (remaining <= 0) {
			$countdown.text('00:00');
			setStatus('expired', 'مهلت پرداخت این سفارش به پایان رسید.');
			clearInterval(countdownTimer);
			if (pollTimer) clearInterval(pollTimer);
			return;
		}
		var minutes = Math.floor(remaining / 60000);
		var seconds = Math.floor((remaining % 60000) / 1000);
		$countdown.text(
			String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0')
		);
	}
	var countdownTimer = setInterval(tickCountdown, 1000);
	tickCountdown();

	// --- وضعیت ---
	function setStatus(type, text) {
		$statusBox.removeClass('cp-success cp-expired').addClass('cp-' + type);
		$statusText.text(text);
	}

	// --- پرسش دوره‌ای از سرور برای بررسی تأیید پرداخت ---
	function pollStatus() {
		$.post(Cryptovali.ajax_url, {
			action: 'cp_check_order_status',
			nonce: Cryptovali.nonce,
			order_id: orderId
		}).done(function (res) {
			if (res && res.success && res.data) {
				if (res.data.status === 'paid') {
					setStatus('success', 'پرداخت شما تأیید شد! در حال انتقال...');
					clearInterval(countdownTimer);
					clearInterval(pollTimer);
					if (res.data.redirect) {
						setTimeout(function () {
							window.location.href = res.data.redirect;
						}, 1500);
					}
				} else if (res.data.status === 'expired') {
					setStatus('expired', 'مهلت پرداخت این سفارش به پایان رسید.');
					clearInterval(countdownTimer);
					clearInterval(pollTimer);
				}
			}
		});
	}
	pollTimer = setInterval(pollStatus, 8000);
	pollStatus();
});
