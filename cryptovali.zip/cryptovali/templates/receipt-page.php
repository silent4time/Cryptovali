<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * متغیرهای در دسترس: $order, $address, $amount, $symbol, $network, $expires, $network_labels
 */
$qr_payload = $amount . ':' . $address; // فقط جهت نمایش QR ساده؛ برخی کیف پول‌ها از فرمت خاص خودشان پشتیبانی می‌کنند
?>
<div class="cp-receipt-wrap" data-order-id="<?php echo esc_attr( $order->get_id() ); ?>" data-expires="<?php echo esc_attr( $expires ); ?>">

	<h3><?php esc_html_e( 'برای تکمیل سفارش، مبلغ زیر را پرداخت کنید', 'cryptovali' ); ?></h3>

	<p class="cp-network-label">
		<?php echo esc_html( $network_labels[ $network ] ?? $network ); ?>
	</p>

	<div class="cp-amount-box">
		<span class="cp-amount"><?php echo esc_html( rtrim( rtrim( number_format( $amount, 8, '.', '' ), '0' ), '.' ) ); ?></span>
		<span class="cp-symbol"><?php echo esc_html( $symbol ); ?></span>
		<button type="button" class="cp-copy-btn" data-copy="<?php echo esc_attr( $amount ); ?>">
			<?php esc_html_e( 'کپی مبلغ', 'cryptovali' ); ?>
		</button>
	</div>

	<p class="cp-warning">
		⚠️ <?php esc_html_e( 'لطفاً دقیقاً همین مبلغ را ارسال کنید (تا رقم آخر). مبلغ متفاوت ممکن است به‌صورت خودکار شناسایی نشود.', 'cryptovali' ); ?>
	</p>

	<div class="cp-address-box">
		<code id="cp-address"><?php echo esc_html( $address ); ?></code>
		<button type="button" class="cp-copy-btn" data-copy="<?php echo esc_attr( $address ); ?>">
			<?php esc_html_e( 'کپی آدرس', 'cryptovali' ); ?>
		</button>
	</div>

	<div id="cp-qrcode"></div>

	<div class="cp-timer">
		<?php esc_html_e( 'زمان باقی‌مانده:', 'cryptovali' ); ?>
		<span id="cp-countdown">--:--</span>
	</div>

	<div class="cp-status-box">
		<span class="cp-spinner"></span>
		<span id="cp-status-text"><?php esc_html_e( 'در انتظار پرداخت... این صفحه پس از تأیید تراکنش به‌طور خودکار تغییر می‌کند.', 'cryptovali' ); ?></span>
	</div>

</div>
