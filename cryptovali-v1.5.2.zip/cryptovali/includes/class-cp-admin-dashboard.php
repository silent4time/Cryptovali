<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CP_Admin_Dashboard {

	const OPTION_KEY = 'woocommerce_cryptovali_settings';

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'register_menu' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
	}

	public static function register_menu() {
		$cap = 'manage_woocommerce';

		$main_hook = add_menu_page(
			'Cryptovali',
			'Cryptovali',
			$cap,
			'cryptovali',
			[ __CLASS__, 'render_settings_page' ],
			'dashicons-money-alt',
			56
		);

		add_submenu_page(
			'cryptovali',
			'تنظیمات Cryptovali',
			'تنظیمات',
			$cap,
			'cryptovali',
			[ __CLASS__, 'render_settings_page' ]
		);

		add_submenu_page(
			'cryptovali',
			'تراکنش‌های Cryptovali',
			'تراکنش‌ها',
			$cap,
			'cryptovali-transactions',
			[ __CLASS__, 'render_transactions_page' ]
		);
	}

	public static function enqueue_assets( $hook ) {
		if ( strpos( $hook, 'cryptovali' ) === false ) {
			return;
		}
		wp_enqueue_style( 'cryptovali-admin', CRYPTOVALI_URL . 'assets/css/cp-admin.css', [], CRYPTOVALI_VERSION );
		wp_enqueue_script( 'cryptovali-admin', CRYPTOVALI_URL . 'assets/js/cp-admin.js', [ 'jquery' ], CRYPTOVALI_VERSION, true );
	}

	/**
	 * آیکون «؟» کنار هر فیلد که با کلیک، توضیح فارسی همان فیلد را در یک پاپ‌آپ نشان می‌دهد
	 */
	private static function help_icon( $help_text ) {
		return sprintf(
			' <button type="button" class="cp-help-icon" data-help="%s" aria-label="راهنما">؟</button>',
			esc_attr( $help_text )
		);
	}

	/**
	 * ------------------------------------------------------------------
	 * صفحه تنظیمات اختصاصی (مستقل از صفحه پرداخت‌های ووکامرس)
	 * ------------------------------------------------------------------
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی لازم را ندارید.' );
		}

		$saved = false;

		if ( isset( $_POST['cp_dashboard_save'] ) && check_admin_referer( 'cp_dashboard_settings', 'cp_dashboard_nonce' ) ) {
			$existing = get_option( self::OPTION_KEY, [] );
			$new_values = $existing;

			foreach ( CP_Fields::definitions() as $field ) {
				$key = $field['key'];
				if ( $field['type'] === 'checkbox' ) {
					$new_values[ $key ] = isset( $_POST[ $key ] ) ? 'yes' : 'no';
				} elseif ( $field['type'] === 'textarea' ) {
					$new_values[ $key ] = isset( $_POST[ $key ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) ) : '';
				} elseif ( $field['type'] === 'number' ) {
					$new_values[ $key ] = isset( $_POST[ $key ] ) ? (string) floatval( $_POST[ $key ] ) : $field['default'];
				} else {
					$new_values[ $key ] = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
				}
			}

			update_option( self::OPTION_KEY, $new_values );
			$saved = true;
		}

		$values = get_option( self::OPTION_KEY, [] );

		// اجرای تست زنده‌ی اتصال به گیت‌هاب، اگر کاربر روی دکمه‌ی مربوطه کلیک کرده باشد
		$live_debug = null;
		if ( isset( $_GET['cp_live_debug'] ) && check_admin_referer( 'cp_live_debug' ) ) {
			$live_debug = CP_GitHub_Updater::get_live_debug();
		}
		?>
		<div class="wrap cp-dashboard-wrap">
			<h1>تنظیمات Cryptovali</h1>

			<?php if ( $saved ) : ?>
				<div class="notice notice-success is-dismissible"><p>تنظیمات با موفقیت ذخیره شد.</p></div>
			<?php endif; ?>

			<p class="cp-dashboard-intro">
				این صفحه، داشبورد اختصاصی افزونه Cryptovali است و مستقل از تنظیمات عمومی پرداخت‌های ووکامرس کار می‌کند.
				کنار هر گزینه، روی علامت «؟» کلیک کنید تا توضیح کامل آن را ببینید.
			</p>

			<div class="cp-update-diagnostic">
				<h2>وضعیت بروزرسانی</h2>
				<p>نسخه‌ی نصب‌شده: <strong dir="ltr"><?php echo esc_html( CRYPTOVALI_VERSION ); ?></strong></p>

				<?php if ( null === $live_debug ) : ?>
					<p>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'cp_live_debug', '1' ), 'cp_live_debug' ) ); ?>">
							تست زنده‌ی اتصال به گیت‌هاب
						</a>
					</p>
				<?php else : ?>
					<div class="cp-debug-box">
						<?php if ( ! empty( $live_debug['success'] ) ) : ?>
							<p>
								✅ اتصال موفق بود
								(از طریق <?php echo $live_debug['source'] === 'jsdelivr' ? 'jsDelivr — چون اتصال مستقیم به گیت‌هاب مسدود بود' : 'گیت‌هاب'; ?>).
							</p>
							<p>آخرین نسخه‌ی منتشرشده: <strong dir="ltr"><?php echo esc_html( $live_debug['version'] ); ?></strong> (تگ: <code dir="ltr"><?php echo esc_html( $live_debug['tag_name'] ); ?></code>)</p>
							<p>
								<?php if ( $live_debug['has_update'] ) : ?>
									🔔 نسخه‌ی جدیدتری موجود است. اگر همچنان در صفحه‌ی افزونه‌ها پیام آپدیت نمی‌بینید، از صفحه‌ی افزونه‌ها روی «بررسی بروزرسانی جدید» بزنید یا چند دقیقه صبر کنید.
								<?php else : ?>
									شما از آخرین نسخه‌ی موجود استفاده می‌کنید.
								<?php endif; ?>
							</p>
							<p>مسیر افزونه‌ی شناسایی‌شده توسط سیستم بروزرسانی: <code dir="ltr"><?php echo esc_html( $live_debug['plugin_basename'] ); ?></code></p>
						<?php else : ?>
							<p>❌ اتصال به هیچ‌کدام از منابع (گیت‌هاب و jsDelivr) موفق نبود.</p>
							<p><strong>گیت‌هاب:</strong> <code dir="ltr"><?php echo esc_html( $live_debug['url'] ?? '-' ); ?></code> — خطا: <code dir="ltr"><?php echo esc_html( $live_debug['error'] ?? 'نامشخص' ); ?></code></p>
							<?php if ( ! empty( $live_debug['jsdelivr_url'] ) ) : ?>
								<p><strong>jsDelivr:</strong> <code dir="ltr"><?php echo esc_html( $live_debug['jsdelivr_url'] ); ?></code> — خطا: <code dir="ltr"><?php echo esc_html( $live_debug['jsdelivr_error'] ?? 'نامشخص' ); ?></code></p>
							<?php endif; ?>
							<?php if ( ! empty( $live_debug['body_snippet'] ) ) : ?>
								<p>بخشی از پاسخ سرور:</p>
								<pre dir="ltr"><?php echo esc_html( $live_debug['body_snippet'] ); ?></pre>
							<?php endif; ?>
							<p>این پیام خطا را برای بررسی دقیق‌تر می‌توانید کپی و ارسال کنید.</p>
						<?php endif; ?>
					</div>
					<p>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'cp_live_debug', '1' ), 'cp_live_debug' ) ); ?>">
							تست مجدد
						</a>
					</p>
				<?php endif; ?>
			</div>


			<form method="post">
				<?php wp_nonce_field( 'cp_dashboard_settings', 'cp_dashboard_nonce' ); ?>

				<table class="form-table cp-settings-table" role="presentation">
					<tbody>
					<?php foreach ( CP_Fields::definitions() as $field ) : ?>
						<tr>
							<th scope="row">
								<label for="cp-field-<?php echo esc_attr( $field['key'] ); ?>">
									<?php echo esc_html( $field['label'] ); ?>
									<?php echo self::help_icon( $field['help'] ); ?>
								</label>
							</th>
							<td>
								<?php
								$current = $values[ $field['key'] ] ?? $field['default'];

								if ( $field['type'] === 'checkbox' ) :
									?>
									<label class="cp-toggle">
										<input type="checkbox" id="cp-field-<?php echo esc_attr( $field['key'] ); ?>" name="<?php echo esc_attr( $field['key'] ); ?>" <?php checked( $current, 'yes' ); ?> />
									</label>
								<?php elseif ( $field['type'] === 'textarea' ) : ?>
									<textarea id="cp-field-<?php echo esc_attr( $field['key'] ); ?>" name="<?php echo esc_attr( $field['key'] ); ?>" rows="3" class="large-text"><?php echo esc_textarea( $current ); ?></textarea>
								<?php elseif ( $field['type'] === 'number' ) : ?>
									<input type="number" step="any" id="cp-field-<?php echo esc_attr( $field['key'] ); ?>" name="<?php echo esc_attr( $field['key'] ); ?>" value="<?php echo esc_attr( $current ); ?>" class="small-text" />
								<?php else : ?>
									<input type="text" id="cp-field-<?php echo esc_attr( $field['key'] ); ?>" name="<?php echo esc_attr( $field['key'] ); ?>" value="<?php echo esc_attr( $current ); ?>" class="regular-text" dir="ltr" />
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<p class="submit">
					<button type="submit" name="cp_dashboard_save" class="button button-primary">ذخیره تنظیمات</button>
				</p>
			</form>
		</div>

		<!-- پاپ‌آپ راهنما (مشترک برای همه فیلدها) -->
		<div id="cp-help-popup" class="cp-help-popup" hidden>
			<div class="cp-help-popup-inner">
				<button type="button" id="cp-help-popup-close" class="cp-help-popup-close" aria-label="بستن">×</button>
				<p id="cp-help-popup-text"></p>
			</div>
		</div>
		<?php
	}

	/**
	 * ------------------------------------------------------------------
	 * صفحه تراکنش‌ها: جدول تاریخ، مبلغ، محصول و وضعیت تأیید پرداخت
	 * ------------------------------------------------------------------
	 */
	public static function render_transactions_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی لازم را ندارید.' );
		}

		$paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$per_page = 20;

		$results = wc_get_orders( [
			'payment_method' => 'cryptovali',
			'limit'          => $per_page,
			'page'           => $paged,
			'paginate'       => true,
			'orderby'        => 'date',
			'order'          => 'DESC',
		] );

		$orders      = $results->orders ?? [];
		$total_pages = $results->max_num_pages ?? 1;
		?>
		<div class="wrap cp-dashboard-wrap">
			<h1>تراکنش‌های Cryptovali</h1>

			<?php if ( empty( $orders ) ) : ?>
				<p>هنوز هیچ تراکنشی از طریق Cryptovali ثبت نشده است.</p>
			<?php else : ?>
				<table class="wp-list-table widefat fixed striped cp-transactions-table">
					<thead>
						<tr>
							<th>شماره سفارش</th>
							<th>تاریخ</th>
							<th>محصول(ها)</th>
							<th>مبلغ</th>
							<th>شبکه / ارز</th>
							<th>وضعیت پرداخت</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $orders as $order ) :
							$date       = $order->get_date_created() ? $order->get_date_created()->date_i18n( 'Y-m-d H:i' ) : '-';
							$products   = [];
							foreach ( $order->get_items() as $item ) {
								$products[] = $item->get_name() . ' × ' . $item->get_quantity();
							}
							$product_list = ! empty( $products ) ? implode( '، ', $products ) : '-';

							$expected_amount = $order->get_meta( '_cp_expected_amount' );
							$symbol           = $order->get_meta( '_cp_symbol' );
							$network          = $order->get_meta( '_cp_network' );
							$cp_status        = $order->get_meta( '_cp_status' );

							$amount_display = $expected_amount
								? rtrim( rtrim( number_format( (float) $expected_amount, 8, '.', '' ), '0' ), '.' ) . ' ' . esc_html( $symbol )
								: wc_price( $order->get_total() );

							$network_labels = [
								'BNB_BEP20'  => 'BNB - BEP20',
								'USDT_BEP20' => 'USDT - BEP20',
								'USDT_TRC20' => 'USDT - TRC20',
								'TRX_TRC20'  => 'TRX (Tron)',
							];
							$network_display = $network_labels[ $network ] ?? ( $network ?: '-' );

							switch ( $cp_status ) {
								case 'paid':
									$status_label = 'تأیید شده';
									$status_class = 'cp-status-paid';
									break;
								case 'expired':
									$status_label = 'منقضی شده';
									$status_class = 'cp-status-expired';
									break;
								case 'awaiting_payment':
									$status_label = 'در انتظار پرداخت';
									$status_class = 'cp-status-pending';
									break;
								default:
									$status_label = wc_get_order_status_name( $order->get_status() );
									$status_class = 'cp-status-other';
							}
							?>
							<tr>
								<td>
									<a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">
										#<?php echo esc_html( $order->get_order_number() ); ?>
									</a>
								</td>
								<td><?php echo esc_html( $date ); ?></td>
								<td><?php echo esc_html( $product_list ); ?></td>
								<td dir="ltr"><?php echo wp_kses_post( $amount_display ); ?></td>
								<td><?php echo esc_html( $network_display ); ?></td>
								<td><span class="cp-status-badge <?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $status_label ); ?></span></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<?php if ( $total_pages > 1 ) : ?>
					<div class="tablenav">
						<div class="tablenav-pages">
							<?php
							echo paginate_links( [
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'prev_text' => '&laquo;',
								'next_text' => '&raquo;',
								'total'     => $total_pages,
								'current'   => $paged,
							] );
							?>
						</div>
					</div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}
}
