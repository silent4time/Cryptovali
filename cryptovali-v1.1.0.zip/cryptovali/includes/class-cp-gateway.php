<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
	return;
}

class CP_Gateway extends WC_Payment_Gateway {

	public function __construct() {
		$this->id                 = 'cryptovali';
		$this->icon               = '';
		$this->has_fields         = true;
		$this->method_title       = __( 'درگاه پرداخت ارز دیجیتال Cryptovali', 'cryptovali' );
		$this->method_description = __( 'دریافت مستقیم BNB و USDT (BEP20) و USDT (TRC20) به کیف پول خودتان، بدون کارمزد و بدون واسطه.', 'cryptovali' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );
		$this->enabled     = $this->get_option( 'enabled' );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
		add_action( 'woocommerce_receipt_' . $this->id, [ $this, 'receipt_page' ] );
		add_action( 'woocommerce_thankyou_' . $this->id, [ $this, 'thankyou_page' ] );
	}

	/**
	 * فیلدهای تنظیمات در پنل مدیریت (ووکامرس > تنظیمات > پرداخت‌ها > این افزونه)
	 */
	public function init_form_fields() {
		$this->form_fields = [
			'enabled' => [
				'title'   => __( 'فعال‌سازی', 'cryptovali' ),
				'type'    => 'checkbox',
				'label'   => __( 'فعال کردن پرداخت با ارز دیجیتال', 'cryptovali' ),
				'default' => 'no',
			],
			'title' => [
				'title'       => __( 'عنوان در صفحه پرداخت', 'cryptovali' ),
				'type'        => 'text',
				'default'     => __( 'پرداخت با ارز دیجیتال (BNB / USDT)', 'cryptovali' ),
			],
			'description' => [
				'title'       => __( 'توضیحات', 'cryptovali' ),
				'type'        => 'textarea',
				'default'     => __( 'پرداخت مستقیم به کیف پول فروشگاه از طریق شبکه BSC یا Tron.', 'cryptovali' ),
			],
			'address_section' => [
				'title'       => __( 'آدرس‌های کیف پول', 'cryptovali' ),
				'type'        => 'title',
				'description' => __( 'آدرس هر شبکه را دقیق و بدون فاصله وارد کنید. مسئولیت صحت آدرس با شماست.', 'cryptovali' ),
			],
			'bep20_address' => [
				'title'       => __( 'آدرس کیف پول BEP20 (BNB Smart Chain)', 'cryptovali' ),
				'type'        => 'text',
				'description' => __( 'برای دریافت BNB و USDT روی شبکه BEP20 استفاده می‌شود.', 'cryptovali' ),
			],
			'trc20_address' => [
				'title'       => __( 'آدرس کیف پول TRC20 (Tron)', 'cryptovali' ),
				'type'        => 'text',
				'description' => __( 'برای دریافت USDT روی شبکه TRC20 استفاده می‌شود.', 'cryptovali' ),
			],
			'api_section' => [
				'title'       => __( 'کلیدهای API (رایگان)', 'cryptovali' ),
				'type'        => 'title',
				'description' => __( 'برای تشخیص خودکار واریزی روی شبکه BSC باید یک کلید رایگان از bscscan.com بگیرید (ثبت‌نام رایگان). برای TRC20 نیازی به کلید نیست ولی وارد کردن آن (اختیاری، از trongrid.io) سرعت را بیشتر می‌کند.', 'cryptovali' ),
			],
			'bscscan_api_key' => [
				'title'   => __( 'BscScan API Key', 'cryptovali' ),
				'type'    => 'text',
			],
			'trongrid_api_key' => [
				'title'   => __( 'TronGrid API Key (اختیاری)', 'cryptovali' ),
				'type'    => 'text',
			],
			'confirm_section' => [
				'title' => __( 'تنظیمات تأیید تراکنش', 'cryptovali' ),
				'type'  => 'title',
			],
			'expire_minutes' => [
				'title'       => __( 'مهلت پرداخت (دقیقه)', 'cryptovali' ),
				'type'        => 'number',
				'default'     => 30,
				'description' => __( 'اگر مشتری تا این مدت پرداخت نکند، سفارش لغو می‌شود.', 'cryptovali' ),
			],
			'amount_tolerance' => [
				'title'       => __( 'میزان اغماض مبلغ (٪)', 'cryptovali' ),
				'type'        => 'number',
				'default'     => 0.5,
				'description' => __( 'به‌دلیل نوسان لحظه‌ای نرخ ارز، درصدی اختلاف مبلغ مجاز پذیرفته می‌شود.', 'cryptovali' ),
			],
		];
	}

	/**
	 * نمایش فیلد انتخاب شبکه/ارز در صفحه تسویه‌حساب
	 */
	public function payment_fields() {
		if ( $this->description ) {
			echo wpautop( wp_kses_post( $this->description ) );
		}

		$options = [];
		if ( $this->get_option( 'bep20_address' ) ) {
			$options['BNB_BEP20']  = __( 'BNB (شبکه BEP20)', 'cryptovali' );
			$options['USDT_BEP20'] = __( 'USDT (شبکه BEP20)', 'cryptovali' );
		}
		if ( $this->get_option( 'trc20_address' ) ) {
			$options['USDT_TRC20'] = __( 'USDT (شبکه TRC20 - Tron)', 'cryptovali' );
		}

		echo '<div class="cp-network-select">';
		foreach ( $options as $value => $label ) {
			printf(
				'<p><label><input type="radio" name="cp_network" value="%1$s" %3$s> %2$s</label></p>',
				esc_attr( $value ),
				esc_html( $label ),
				checked( array_key_first( $options ), $value, false )
			);
		}
		echo '</div>';
	}

	/**
	 * اعتبارسنجی فیلدها هنگام ثبت سفارش
	 */
	public function validate_fields() {
		if ( empty( $_POST['cp_network'] ) ) {
			wc_add_notice( __( 'لطفاً شبکه پرداخت را انتخاب کنید.', 'cryptovali' ), 'error' );
			return false;
		}
		return true;
	}

	/**
	 * پردازش پرداخت: محاسبه مبلغ ارز دیجیتال و ذخیره روی سفارش
	 */
	public function process_payment( $order_id ) {
		$order   = wc_get_order( $order_id );
		$network = sanitize_text_field( $_POST['cp_network'] );

		$symbol = ( strpos( $network, 'USDT' ) === 0 ) ? 'USDT' : 'BNB';

		$conversion = CP_Rate::convert_with_nonce( (float) $order->get_total(), $symbol, $order_id );
		if ( is_wp_error( $conversion ) ) {
			wc_add_notice( __( 'خطا در دریافت نرخ ارز، لطفاً کمی بعد دوباره تلاش کنید.', 'cryptovali' ), 'error' );
			return [ 'result' => 'failure' ];
		}

		$address = ( $network === 'USDT_TRC20' )
			? $this->get_option( 'trc20_address' )
			: $this->get_option( 'bep20_address' );

		$expire_minutes = (int) $this->get_option( 'expire_minutes', 30 );

		$order->update_meta_data( '_cp_network', $network );
		$order->update_meta_data( '_cp_symbol', $symbol );
		$order->update_meta_data( '_cp_address', $address );
		$order->update_meta_data( '_cp_expected_amount', $conversion['amount'] );
		$order->update_meta_data( '_cp_rate', $conversion['rate'] );
		$order->update_meta_data( '_cp_created_at', time() );
		$order->update_meta_data( '_cp_expires_at', time() + ( $expire_minutes * 60 ) );
		$order->update_meta_data( '_cp_status', 'awaiting_payment' );
		$order->set_status( 'on-hold', __( 'در انتظار پرداخت ارز دیجیتال', 'cryptovali' ) );
		$order->save();

		return [
			'result'   => 'success',
			'redirect' => $order->get_checkout_payment_url( true ),
		];
	}

	/**
	 * صفحه‌ی نمایش آدرس، QR کد و شمارش‌معکوس برای پرداخت
	 */
	public function receipt_page( $order_id ) {
		$order = wc_get_order( $order_id );

		$address  = $order->get_meta( '_cp_address' );
		$amount   = $order->get_meta( '_cp_expected_amount' );
		$symbol   = $order->get_meta( '_cp_symbol' );
		$network  = $order->get_meta( '_cp_network' );
		$expires  = (int) $order->get_meta( '_cp_expires_at' );

		$network_labels = [
			'BNB_BEP20'  => 'BNB - BEP20 (BNB Smart Chain)',
			'USDT_BEP20' => 'USDT - BEP20 (BNB Smart Chain)',
			'USDT_TRC20' => 'USDT - TRC20 (Tron)',
		];

		include CRYPTOVALI_PATH . 'templates/receipt-page.php';
	}

	public function thankyou_page( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( $order && $order->get_meta( '_cp_status' ) === 'awaiting_payment' ) {
			echo '<p>' . esc_html__( 'در انتظار تأیید پرداخت شما روی بلاک‌چین هستیم. این صفحه به‌صورت خودکار به‌روزرسانی می‌شود.', 'cryptovali' ) . '</p>';
		}
	}
}
